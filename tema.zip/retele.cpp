// Copyright 2022 Buzea Alexandru-Mihai-Iulian 321CAb
// Contact: alexandru.buzea2007@stud.acs.upb.ro

#include "task1.h"

int main() {
    Task1 *task = new Task1();
    task->solve();
    return 0;
}