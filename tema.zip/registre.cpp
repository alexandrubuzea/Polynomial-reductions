// Copyright 2022 Buzea Alexandru-Mihai-Iulian 321CAb
// Contact: alexandru.buzea2007@stud.acs.upb.ro

#include "task3.h"

int main() {
    Task3 *task = new Task3();
    task->solve();
    return 0;
}