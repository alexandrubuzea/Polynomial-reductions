// Copyright 2022 Buzea Alexandru-Mihai-Iulian 321CAb
// Contact: alexandru.buzea2007@stud.acs.upb.ro

#include "task2.h"

int main() {
    Task2 *task = new Task2();
    task->solve();
    return 0;
}